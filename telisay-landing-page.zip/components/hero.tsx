"use client"

import { Play } from "lucide-react"

export function Hero() {
  return (
    <section className="px-8 py-20">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-2 gap-16 items-start">
          {/* Left side - Heading and description */}
          <div className="pt-8">
            <h1 className="text-6xl font-bold leading-tight text-black mb-8">
              Authentic Voice,
              <br />
              Real Reviews
            </h1>
            <p className="text-lg text-gray-600 leading-relaxed mb-8">
              Collect genuine voice reviews from customers. Let them speak their truth. Build trust through authentic
              testimonials that resonate.
            </p>
            <button className="bg-blue-500 hover:bg-blue-600 text-white font-medium px-8 py-3 rounded-full transition">
              Get Started
            </button>
          </div>

          {/* Right side - Phone mockup and visuals */}
          <div className="relative h-96 flex items-center justify-center">
            <div className="absolute inset-0 flex items-center justify-center">
              {/* Phone frame */}
              <div className="w-48 h-96 bg-gradient-to-b from-gray-900 to-gray-800 rounded-3xl shadow-2xl p-3 relative z-20">
                <div className="w-full h-full bg-white rounded-2xl overflow-hidden flex flex-col">
                  {/* Phone notch */}
                  <div className="h-6 bg-gray-900 rounded-b-2xl flex items-center justify-center">
                    <div className="w-24 h-4 bg-gray-800 rounded-full"></div>
                  </div>

                  {/* Phone content */}
                  <div className="flex-1 p-4 overflow-hidden">
                    <div className="text-sm font-semibold text-gray-900 mb-3">Voice Reviews</div>

                    {/* Review card */}
                    <div className="bg-gradient-to-b from-gray-100 to-white p-4 rounded-lg border border-gray-200 mb-3">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-8 h-8 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full"></div>
                        <div className="flex-1">
                          <div className="text-xs font-semibold text-gray-900">Sarah M.</div>
                          <div className="text-xs text-yellow-500 flex gap-0.5">★★★★★</div>
                        </div>
                      </div>
                      <div className="bg-white rounded p-2 flex items-center justify-center gap-1 mb-2 border border-gray-200">
                        <Play size={12} className="text-blue-500" />
                        <div className="h-1 w-12 bg-gradient-to-r from-blue-400 to-gray-300 rounded"></div>
                      </div>
                      <div className="text-xs text-gray-500">2 days ago</div>
                    </div>

                    {/* Second review card */}
                    <div className="bg-gradient-to-b from-gray-100 to-white p-4 rounded-lg border border-gray-200">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-8 h-8 bg-gradient-to-br from-pink-400 to-orange-500 rounded-full"></div>
                        <div className="flex-1">
                          <div className="text-xs font-semibold text-gray-900">John K.</div>
                          <div className="text-xs text-yellow-500 flex gap-0.5">★★★★★</div>
                        </div>
                      </div>
                      <div className="bg-white rounded p-2 flex items-center justify-center gap-1 mb-2 border border-gray-200">
                        <Play size={12} className="text-blue-500" />
                        <div className="h-1 w-12 bg-gradient-to-r from-blue-400 to-gray-300 rounded"></div>
                      </div>
                      <div className="text-xs text-gray-500">1 day ago</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Floating cards */}
              <div className="absolute top-0 -left-32 bg-white rounded-xl shadow-lg p-4 border border-gray-200 z-10 w-40">
                <div className="text-xs text-gray-600 mb-2">Customer Reviews</div>
                <div className="flex items-center gap-2 mb-3">
                  <div className="text-sm font-bold text-blue-600">4.9</div>
                  <div className="flex gap-0.5">
                    <span className="text-xs text-yellow-500">★★★★★</span>
                  </div>
                </div>
                <div className="text-xs text-gray-500">From 2,349 reviews</div>
              </div>

              {/* Bottom floating element */}
              <div className="absolute bottom-0 -right-24 bg-black rounded-2xl p-4 z-10 w-40">
                <div className="text-white text-xs font-medium mb-2">Approve & Publish</div>
                <div className="text-white text-2xl font-bold">↗</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
