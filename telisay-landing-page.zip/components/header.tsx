"use client"

export function Header() {
  return (
    <header className="flex items-center justify-between px-8 py-6 border-b border-gray-100">
      <div className="text-2xl font-bold text-black">Telisay</div>
      <nav className="flex items-center gap-8">
        <a href="#" className="text-sm text-gray-600 hover:text-gray-900">
          Features
        </a>
        <a href="#" className="text-sm text-gray-600 hover:text-gray-900">
          Pricing
        </a>
        <a href="#" className="text-sm text-gray-600 hover:text-gray-900">
          FAQ
        </a>
        <a href="#" className="text-sm text-gray-600 hover:text-gray-900">
          Blog
        </a>
        <button className="text-sm text-blue-600 font-medium hover:text-blue-700">Sign In</button>
      </nav>
    </header>
  )
}
