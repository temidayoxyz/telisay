"use client"

export function TrustedBy() {
  const logos = [
    { name: "Acme", color: "text-gray-400" },
    { name: "Globe", color: "text-gray-400" },
    { name: "Cursor", color: "text-gray-400" },
    { name: "Tunnel", color: "text-gray-400" },
    { name: "Flow", color: "text-gray-400" },
  ]

  return (
    <section className="px-8 py-16 border-t border-gray-100">
      <div className="max-w-7xl mx-auto">
        <p className="text-center text-sm text-gray-500 mb-12">Trusted by the leaders</p>
        <div className="flex items-center justify-center gap-16">
          {logos.map((logo, i) => (
            <div key={i} className={`text-2xl font-bold ${logo.color}`}>
              {logo.name}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
