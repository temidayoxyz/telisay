"use client"

export function CTA() {
  return (
    <section className="px-8 py-20">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-5xl font-bold text-black mb-6">Start Collecting Voice Reviews Today</h2>
        <p className="text-xl text-gray-600 mb-10">
          Join hundreds of businesses collecting authentic voice reviews. Build trust through real customer voices.
        </p>
        <button className="bg-blue-500 hover:bg-blue-600 text-white font-medium px-8 py-4 rounded-full text-lg transition">
          Launch Your Review Wall
        </button>
      </div>
    </section>
  )
}
