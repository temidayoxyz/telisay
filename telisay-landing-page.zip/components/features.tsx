"use client"

import { BarChart3, PieChart, Radio } from "lucide-react"

export function Features() {
  return (
    <section className="px-8 py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-sm text-gray-600 mb-4 inline-block px-4 py-1 border border-gray-300 rounded-full">
            Features
          </p>
          <h2 className="text-5xl font-bold text-black">
            Streamline Reviews with
            <br />
            Smart Tools
          </h2>
        </div>

        <div className="grid grid-cols-3 gap-8">
          {/* Feature 1 */}
          <div className="bg-white p-8 rounded-2xl border border-gray-200 hover:border-gray-300 transition">
            <h3 className="text-xl font-bold text-black mb-3">Voice Recordings</h3>
            <p className="text-gray-600 mb-8">
              Customers record authentic testimonials directly. Raw, genuine, and powerful.
            </p>
            <div className="h-40 bg-gradient-to-b from-blue-100 to-blue-50 rounded-xl flex items-end justify-center p-4">
              <div className="w-8 h-24 bg-blue-500 rounded-lg flex items-center justify-center">
                <Radio size={16} className="text-white" />
              </div>
            </div>
          </div>

          {/* Feature 2 */}
          <div className="bg-white p-8 rounded-2xl border border-gray-200 hover:border-gray-300 transition">
            <h3 className="text-xl font-bold text-black mb-3">Smart Approval</h3>
            <p className="text-gray-600 mb-8">
              Review and approve testimonials before they go live. Full control and moderation.
            </p>
            <div className="h-40 bg-gradient-to-b from-blue-100 to-blue-50 rounded-xl flex items-center justify-center">
              <BarChart3 size={48} className="text-blue-500" />
            </div>
          </div>

          {/* Feature 3 */}
          <div className="bg-white p-8 rounded-2xl border border-gray-200 hover:border-gray-300 transition">
            <h3 className="text-xl font-bold text-black mb-3">Public Wall</h3>
            <p className="text-gray-600 mb-8">
              Showcase all approved reviews on your public profile. Build social proof instantly.
            </p>
            <div className="h-40 bg-gradient-to-b from-blue-100 to-blue-50 rounded-xl flex items-center justify-center">
              <PieChart size={48} className="text-blue-500" />
            </div>
          </div>

          {/* Feature 4 */}
          <div className="bg-white p-8 rounded-2xl border border-gray-200 hover:border-gray-300 transition">
            <h3 className="text-xl font-bold text-black mb-3">Easy Sharing</h3>
            <p className="text-gray-600 mb-8">
              Share your unique public link with customers. One-click review submission.
            </p>
            <div className="h-40 bg-gradient-to-b from-blue-100 to-blue-50 rounded-xl flex items-center justify-center">
              <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center text-white font-bold">
                ↗
              </div>
            </div>
          </div>

          {/* Feature 5 */}
          <div className="bg-white p-8 rounded-2xl border border-gray-200 hover:border-gray-300 transition">
            <h3 className="text-xl font-bold text-black mb-3">Analytics</h3>
            <p className="text-gray-600 mb-8">
              Track review submissions, approvals, and engagement metrics in real-time.
            </p>
            <div className="h-40 bg-gradient-to-b from-blue-100 to-blue-50 rounded-xl flex items-center justify-center">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600">5K+</div>
                <div className="text-xs text-gray-500 mt-1">Reviews</div>
              </div>
            </div>
          </div>

          {/* Feature 6 */}
          <div className="bg-white p-8 rounded-2xl border border-gray-200 hover:border-gray-300 transition">
            <h3 className="text-xl font-bold text-black mb-3">Customization</h3>
            <p className="text-gray-600 mb-8">Match your brand with custom colors, themes, and review wall designs.</p>
            <div className="h-40 bg-gradient-to-b from-blue-100 to-blue-50 rounded-xl flex items-center justify-center">
              <div className="flex gap-2">
                <div className="w-12 h-12 bg-blue-500 rounded-lg"></div>
                <div className="w-12 h-12 bg-purple-500 rounded-lg"></div>
                <div className="w-12 h-12 bg-orange-500 rounded-lg"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
